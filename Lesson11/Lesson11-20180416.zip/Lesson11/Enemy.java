public class Enemy extends Character{
    //-------フィールド-------
    //add here
    
    //-------コンストラクタ-------
    //add here

    //-------メソッド-------
    //add here
    public void attack(Hero hero) {
	hero.damege(atk);
	System.out.println(this.getName()+"は"+hero.getName()+"に"+atk+"のダメージを与えた！");
    }
}
