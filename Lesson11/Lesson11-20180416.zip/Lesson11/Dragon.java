public class Dragon {
    //-------フィールド-------
    private int hp, level, mp;
    private String name, type;

    //-------コンストラクタ-------
    public Dragon(String name, int hp, int level, int mp){
	this.hp = hp;
	this.level = level;
	this.name = name;
	this.type = "Dragon";
	this.mp = mp;
    }

    //-------メソッド-------
    public int getHp(){
	return this.hp;
    }
    
    public int getLevel(){
	return this.level;
    }
    
    public String getName(){
	return this.name;
    }
    
    public String getType(){
	return this.type;
    }
    
    public void showStatus() {
	System.out.println("Name:"+this.getName());
	System.out.println("Type:"+this.getType());
	System.out.println("Level:"+this.getLevel());
	System.out.println("HP:"+this.getHp());
	System.out.println("MP:"+this.mp);
    }
    
    public void attack(){
	System.out.println(this.getName()+"の攻撃");
    }
    
    public void encountMonster() {
	System.out.println(this.getName()+"が現れた！");
    }
}
