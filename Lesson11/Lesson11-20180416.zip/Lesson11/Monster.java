public abstract class Monster {
    //-------フィールド-------
    //add here

    //-------コンストラクタ-------
    //add here

    //-------メソッド-------
    //add here
    
}
