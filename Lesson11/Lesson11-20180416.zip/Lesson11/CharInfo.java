public interface CharInfo {
	void showStatus();
}