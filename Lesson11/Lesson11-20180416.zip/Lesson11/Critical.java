public interface Critical {
    //add here
}
