public class Hero extends Character {
    //-------フィールド-------
    //add here
    
    //-------コンストラクタ-------
    //add here
    
    //-------メソッド-------
    //add here
    public void attack(Enemy enemy) {
	enemy.damege(atk);
	System.out.println(this.getName()+"は"+enemy.getName()+"に"+atk+"のダメージを与えた！");
    }
    
}
