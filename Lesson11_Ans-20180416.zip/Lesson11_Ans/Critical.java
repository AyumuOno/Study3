public interface Critical {
    int CRITICAL = 2;
    int calcCritical(int atk);
}
