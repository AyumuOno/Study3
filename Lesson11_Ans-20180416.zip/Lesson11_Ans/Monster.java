public abstract class Monster {
    //-------フィールド-------
    private int hp, level;
    private String name, type;

    //-------コンストラクタ-------
    public Monster(int hp, int level, String name, String type){
	this.hp = hp;
	this.level = level;
	this.name = name;
	this.type = type;
    }

    //-------メソッド-------
    public int getHp(){
	return this.hp;
    }
    
    public int getLevel(){
	return this.level;
    }
    
    public String getName(){
	return this.name;
    }

    public String getType(){
	return this.type;
    }
    
    public abstract void showStatus();
    
    public abstract void encountMonster();
}
