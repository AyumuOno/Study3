public class Hero extends Character implements CharInfo, Critical{
    //-------フィールド-------
    private int atk; //add 11_1

    //-------コンストラクタ-------
    public Hero(String name, int hp, int atk){ // add 11_1
	super(name, hp);
	this.atk = atk;
    }

    //-------メソッド-------
    public void attack(Enemy enemy) { // add 11_1
	System.out.println(this.getName()+"の攻撃！");
	enemy.damege(atk);
	System.out.println(this.getName()+"は"+enemy.getName()+"に"+atk+"のダメージを与えた！");
	System.out.println(enemy.getName()+"の残りHPは"+enemy.getHp()); //add 11_2
    }

    //add 11_1
    public int getAtk() {
	return this.atk;
    }

    //add 11_1
    @Override //@Overrideは「このメソッドはオーバライドしているよ」ってことを示す注釈
    public void printName(){
	System.out.println("プレイヤーのキャラクターは"+this.getName()+"だ！");
    }
    
    //add 11_2
    @Override
    public void showStatus(){
	System.out.println(this.getName()+"のステータス");
	System.out.println("HP:"+this.getHp());
	System.out.println("ATK:"+this.getAtk());
    }
    
    //add 11_3
    @Override
    public int calcCritical(int atk){
	return atk*CRITICAL;
    }

    //add 11_3
    public void criticalAttack(Enemy enemy) {
	System.out.println(this.getName()+"の攻撃！");
	System.out.println("クリティカルヒット！！");
	enemy.damege(calcCritical(atk));
	System.out.println(this.getName()+"は"+enemy.getName()+"に"+calcCritical(atk)+"のダメージを与えた！");
	System.out.println(enemy.getName()+"の残りHPは"+enemy.getHp());
    }
}
