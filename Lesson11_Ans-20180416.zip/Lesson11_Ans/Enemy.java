public class Enemy extends Character implements CharInfo{
    //-------フィールド-------
    //add 11_1
    private int atk;

    //-------コンストラクタ-------
    //add 11_1
    public Enemy(String name, int hp, int atk){
	super(name, hp);
	this.atk = atk;
    }

    //-------メソッド-------
    //add 11_1
    public void attack(Hero hero) {
	hero.damege(atk);
	System.out.println(this.getName()+"は"+hero.getName()+"に"+atk+"のダメージを与えた！");
	System.out.println(hero.getName() + "の残りHPは" + hero.getHp());
    }

    //add 11_1
    public int getAtk() {
	return this.atk;
    }

    //add 11_1
    @Override //@Overrideは「このメソッドはオーバライドしているよ」ってことを示す注釈
    public void printName(){
	System.out.println("敵のキャラクターは"+this.getName()+"だ！");
    }

    //add 11_2
    @Override
    public void showStatus(){
	System.out.println(this.getName() + "のステータス");
	System.out.println("HP:"+this.getHp());
	System.out.println("ATK:"+this.getAtk());
    }
}
