public class Slime extends Monster implements Cloneable{
    //-------コンストラクタ-------
    public Slime(String name, int hp, int level){
	super(hp, level, name, "Slime");
    }

    //-------メソッド-------
    @Override
    public void showStatus() {
	System.out.println("Name:"+this.getName());
	System.out.println("Type:"+this.getType());
	System.out.println("Level:"+this.getLevel());
	System.out.println("HP:"+this.getHp());
    }
    
    public void run(){
	System.out.println(this.getName()+"は逃げ出した");
    }
    
    @Override
    public void encountMonster() {
	System.out.println(this.getName()+"が現れた！");
    }

    @Override
    public Slime clone(String name) {
	System.out.println(getName() + "が分裂し，"+name+"が誕生した！");
	return (new Slime(name, getHp(), getLevel()));
    }
}
