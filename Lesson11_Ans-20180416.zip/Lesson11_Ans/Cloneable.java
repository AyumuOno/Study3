public interface Cloneable {
    Cloneable clone(String name);
}
